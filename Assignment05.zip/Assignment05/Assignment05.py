#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   KMiller
# Date:  April 28, 2019
# ChangeLog: (Who, When, What)
#   KMiller, 04/29/2019, Created starting template
#   <Kylie>, ???, Added code to complete assignment 5
#--------------------------------------------------#

#Load data from file
objFileName= "c:\_PythonClass\ToDo.txt"
dicRow0= {"Task:", "Priority:"}
dicRow1= {"Clean House", "Low"}
dicRow2= {"Pay Bills",  "High"}
lstTable= [dicRow0,dicRow1,dicRow2]
#Display Menu Options 
while(True):
    print("""
    1) Show Current data
    2) Add a New Item
    3) Remove an Exisiting Item
    4) Save Data to File
    5) Exit Program
    """)
    strChoice= str(input("Which Option Would You Like to Perform? [1 to 5] -\n"))
#Display Current Data
    if(strChoice.strip() =='1'): print(lstTable)
#Add New Information
    elif(strChoice.strip() =='2'):
        t= input("Task: ")
        p= input("Priority: ")
        lstNewRow = [t, p]
        lstTable.append(lstNewRow)
        print(lstTable)
#Remove New Item
    elif(strChoice.strip() == '3'):
        lstTable.remove(lstNewRow)
        print(lstTable)
#Save to File
    elif(strChoice.strip() == '4'):
        objF= open("ToDo.txt", "a")
        objF.write(str(lstTable))
        objF.close()
        print("Data Saved!")
#Exit Program
    elif(strChoice.strip() == '5'):break
        
