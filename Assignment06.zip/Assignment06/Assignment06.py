#Step 1
# Load data from ToDo.txt
objFileName= "c:\_PythonClass\ToDo.txt"
dicRow0= {"Task:", "Priority:"}
dicRow1= {"Clean House", "Low"}
dicRow2= {"Pay Bills",  "High"}
lstTable= [dicRow0,dicRow1,dicRow2]

# Step 2
#Dispay a menu of choices to the user    
def DisplayMenu() :
    Menu = """
    1) Show Current data
    2) Add a New Item
    3) Remove an Exisiting Item
    4) Save Data to File
    5) Exit Program
    """
    print(Menu)    
DisplayMenu()
strChoice= str(input("Which Option Would You Like to Perform? [1 to 5] -\n"))

# Step 3
# Display all todo items to user
def DisplayToDo() :
    ToDo= "lstTable"
    
DisplayToDo()
if(strChoice.strip() =='1'):print(lstTable)
strChoice= str(input("Which Option Would You Like to Perform? [1 to 5] -\n"))

#Step 4
# Add new item to list/table
def AddNew() :
    t= input("Task:")
    p= input("Priority:")
    NewRow= [t, p]
    lstTable.append(NewRow)
    
AddNew()
if(strChoice.strip() =='2'): print(lstTable)
strChoice= str(input("Which Option Would You Like to Perform? [1 to 5] -\n"))

#Step 5
#Remove new item from list/table
def RemoveNew() :
    del lstTable[3]
    if(strChoice.strip() == '3'): print(lstTable)
    
RemoveNew()
strChoice= str(input("Which Option Would You Like to Perform? [1 to 5] -\n"))

#Step 6
#Save to ToDo.txt file
def Save() :
    objF= open("ToDo.txt", "a")
    objF.write(str(lstTable))
    objF.close()
    
Save()
if(strChoice.strip() == '4'): print("Data Saved!")
strChoice= str(input("Which Option Would You Like to Perform? [1 to 5] -\n"))

#Step 7
#Exit program
def Exit() :
    if(strChoice.strip() == '5'):
        Exit()
